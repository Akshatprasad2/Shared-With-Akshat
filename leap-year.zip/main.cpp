/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{ 
    int year, a, b, c;
    cout<<"Enter a year"<<endl;
    cin>>year;
    b= year%4;
    c= year%100;
    a= year%400;
 if(b==0, c!=0){
     cout<<"It is a leap year"<<endl;
 }
else if(c==0, a==0){
    cout<<"It is a leap year"<<endl;
}
else {
    cout<<"It is not a leap year"<<endl;
}
    
    return 0;
}
