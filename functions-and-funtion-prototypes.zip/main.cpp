/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int sum(int, int);
void g(void);

int main()
{ 
    int num1, num2;
cout<<"Enter your first number"<<endl;
cin>>num1;
cout<<"Enter your second number"<<endl;
cin>>num2;

cout<<"The sum is "<<sum(num1, num2)<<endl;
 g();
   

    return 0;
}

int sum(int a, int b){
    int c=a+b;
    return c;
}

void g(){
    cout<<"Good Night"<<endl;
}