/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
// int sum(int a, int b){
    
//     return a+b;
// }
// int sum(int a, int b, int c){
    
//     return a+b+c;
// }
// int main()
// {
//     cout<<"The sum of 3 and 6 is "<<sum(3,6)<<endl;
//     cout<<"The sum of 3,6 and 7 is "<<sum(3,6,7);

int volume(int r, int h){
    return (3.14*r*r*h);
}

int volume(int a){
    return (a*a*a);
}

int volume(int l, int b, int h){
    return (l*b*h);
}


int main(){
    
    cout<<"The volume of cylinder is "<<volume(6,7)<<endl;
    cout<<"The volume of cube is "<<volume(6)<<endl;
    cout<<"The volume  of cuboid is 0"<<volume(3,4,5)<<endl;


   
    return 0;
}

