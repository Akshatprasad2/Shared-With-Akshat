/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <string>

using namespace std;

class binary{
    private:
    string s;
    void chk_bin(void);
    
    public:
    void read(void);
    void ones_complement(void);
    void display(void);
};

void binary :: read(void){
    cout<<"Enter a binary number "<<endl;
    cin>>s;
}

void binary :: chk_bin(void){
    for(int i=0; i < s.length(); i++){
        if(s.at(i)!='0' && s.at(i)!='1'){
            cout<<"Incorrect binary format "<<endl;
            exit(0); 
        }
        
    }
} 

void binary :: ones_complement(void){
    for(int i=0; i < s.length(); i++){
        if(s.at(i)=='0'){
            s.at(i)='1';
        }
        else{
            s.at(i)='0';
        }
    }
}

void binary :: display(void){
    cout<<"The one's complement is "<<endl;
    for(int i=0; i< s.length(); i++){
        cout<<s.at(i);
    }
}



int main()
{
    binary b;
    b.read();
   // b.chk_bin();
    b.ones_complement();
    b.display();

    return 0;
}
