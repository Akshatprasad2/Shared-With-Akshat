/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int sum(int a, int b){
    int c= a+b;
    return c;
}

void swapRefrenceVar(int &a, int &b){
    int temp=a;
    a=b;
    b=temp;
}

int main()
{ 
    int x=4, y=5;
    cout<<"The value of x is "<<x<<" and the value of y is "<<y<<endl;
    swapRefrenceVar(x,y);
    cout<<"The value of x is "<<x<<" and the value of y is "<<y<<endl;

    return 0;
}
