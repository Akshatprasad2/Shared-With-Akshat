#include <iostream>

using namespace std;

int main()
{ 
  int a, b, c;
  cout<<"Enter a Value"<<endl;
  cin>>a;
  cout<<"Enter a Value"<<endl;
  cin>>b;
  cout<<"Enter a Value"<<endl;
  cin>>c;
   if (a>b, a>c){
       cout<<"The geatest value is"<<a<<endl;
   }
   if (b>a, b>c){
       cout<<"The geatest value is"<<b<<endl;
   }
   else if (c>a, c>b){
       cout<<"The greatest value is"<<c<<endl;
   }
   
  
  
    return 0;
}
